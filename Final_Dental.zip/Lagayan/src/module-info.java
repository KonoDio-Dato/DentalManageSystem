/**
 * 
 */
/**
 * 
 */
module Lagayan {
	requires java.desktop;
}